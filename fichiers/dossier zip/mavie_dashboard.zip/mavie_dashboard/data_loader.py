
import pandas as pd

def charger_fichier(path):
    xls = pd.ExcelFile(path)
    individus = pd.read_excel(xls, sheet_name=0)
    accidents = pd.read_excel(xls, sheet_name=1)
    return individus, accidents
