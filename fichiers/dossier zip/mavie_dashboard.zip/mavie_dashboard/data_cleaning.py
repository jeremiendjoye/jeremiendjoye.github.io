import pandas as pd
import json
from unidecode import unidecode

# Fonction principale pour nettoyer un DataFrame contenant des informations sur les individus
def nettoyer_dataframe_individu(df1):
    # Fonction pour charger des chaînes JSON en toute sécurité
    def safe_json_loads(x):
        try:
            return json.loads(x)  # Tente de charger la chaîne JSON
        except (json.JSONDecodeError, TypeError):
            return []  # Retourne une liste vide en cas d'erreur

    # Fonction pour transformer une liste de dictionnaires JSON en colonnes aplaties
    def flatten_json_list(liste, prefix):
        resultat = {}
        for i, elem in enumerate(liste):  # Parcourt chaque élément de la liste
            for key, value in elem.items():  # Parcourt chaque clé-valeur du dictionnaire
                # Nettoie les clés pour les rendre uniformes
                key_clean = (
                    unidecode(key)
                    .lower()
                    .replace(" ", "_")
                    .replace("-", "_")
                    .replace("'", "")
                    .replace("?", "")
                )
                # Ajoute les clés nettoyées au dictionnaire avec un préfixe
                resultat[f"{prefix}_{i+1}_{key_clean}"] = value
        return pd.Series(resultat)  # Retourne les données sous forme de Series pandas

    # Dictionnaire pour renommer les colonnes du DataFrame
    noms_colonnes = {
        # Exemple : 'VOLONTAIRE N°' devient 'numero_volontaire'
        'VOLONTAIRE N°': 'numero_volontaire',
        'ANNEE DE NAISSANCE': 'annee_naissance',
        'GENRE': 'genre',
        # Ajout de nombreuses autres colonnes pour uniformiser les noms
        'DATE DE REMPLISSAGE': 'date_remplissage',
        'Où êtes-vous né(e) ?': 'lieu_naissance',
        'Merci de préciser votre pays de naissance': 'pays_naissance',
        'À quel âge êtes-vous arrivé(e) en France ? ': 'age_arrivee_france',
        'Quelle est votre situation actuelle par rapport à l\'emploi ?': 'situation_emploi',
        'Quelle est votre profession actuelle ou la dernière profession que vous avez exercée ?': 'profession_actuelle',
        'Quel est le diplôme le plus élevé que vous avez obtenu ?': 'diplome_obtenu',
        'Cochez toutes les activités que vous pratiquez.': 'activites_pratiquees',
        'Avez-vous pratiqué une activité physique ou sportive au cours des 12 derniers mois ? ': 'activite_physique_12mois',
        'Quelles sont les activités sportives que vous pratiquez ?': 'activites_sportives',
        'Vous êtes :': 'statut_personnel',
        'Quel est votre poids actuel en kg ?': 'poids_kg',
        'Quelle est votre taille actuelle en cm ?': 'taille_cm',
        'Sur cette échelle de 1 à 10, en moyenne au cours de la semaine passée, comment vous êtes-vous senti sur le plan physique ? ': 'bien_etre_physique',
        'Sur cette échelle de 1 à 10, en moyenne au cours de la semaine passée, comment vous êtes-vous senti sur le plan mental ? ': 'bien_etre_mental',
        'Au cours des 12 derniers mois, avez-vous eu un ou des accidents ?': 'accidents_12mois',
        'Quels sont les accidents que vous avez eu ?': 'types_accidents',
        'Souffrez-vous d\'une déficience ou d\'un handicap ?': 'deficience_handicap',
        'Pour quel(s) mouvement(s) de la vie quotidienne présentez-vous des difficultés ?': 'difficulte_mouvement_1',
        'Pour quel(s) mouvement(s) de la vie quotidienne présentez-vous des difficultés ?_1': 'difficulte_mouvement_2',
        'Pour quel(s) mouvement(s) de la vie quotidienne présentez-vous des difficultés ?_2': 'difficulte_mouvement_3',
        'Pour quel(s) mouvement(s) de la vie quotidienne présentez-vous des difficultés ?_3': 'difficulte_mouvement_4',
        'Pour quel(s) mouvement(s) de la vie quotidienne présentez-vous des difficultés ?_4': 'difficulte_mouvement_5',
        'Pour quel(s) mouvement(s) de la vie quotidienne présentez-vous des difficultés ?_5': 'difficulte_mouvement_6',
        'Combien fumez-vous ou fumiez-vous de cigarettes, cigarillos, cigares ou pipes par jour ?': 'fumeur_cigarettes_par_jour',
        'Avez-vous consommé du cannabis (haschisch, marijuana, herbe, joint, shit) au cours des 30 derniers jours ?': 'consommation_cannabis_30j',
        'Combien de fois, au cours des 30 derniers jours, en avez-vous consommé ?': 'frequence_cannabis',
        'A quelle fréquence consommez-vous de l\'alcool (Vin, bière, cidre,apéritif, digestif, …) ?': 'frequence_alcool',
        'Combien de verres contenant de l\'alcool consommez-vous un jour typique où vous buvez ? ': 'verres_alcool_typique',
        'Avec quelle fréquence buvez-vous 6 verres ou davantage lors d\'une occasion particulière ? ': 'frequence_exces_alcool',
        'DATE DE REMPLISSAGE.FOYER': 'date_remplissage_foyer',
        'Combien de personnes vivent avec vous dans votre foyer ?': 'nombre_personnes_foyer',
        'Comment vivez-vous ?': 'mode_vie',
        'Qui sont les personnes vivant avec vous dans votre foyer ?': 'personnes_dans_foyer',
        'Parmi les tranches suivantes, dans laquelle se situe le revenu mensuel net de vo': 'revenu_mensuel',
        'Avez-vous des animaux domestiques ?': 'animaux_domestiques',
        'Quelle est la race de votre(vos) chien(s) ?': 'race_chien',
        'Quel est le code postal de votre commune d\'habitation ?': 'code_postal',
        'Sélectionnez votre commune': 'commune_habitation',
        'Votre lieu de résidence se trouve en :': 'zone_residence',
        'Quel est le type d\'habitat de votre voisinage ?': 'type_habitat_voisinage',
        'Vous habitez dans :': 'type_logement',
        'Vous occupez le logement en tant que :': 'statut_occupation',
        'A quel étage habitez-vous ?': 'etage_residence',
        'Dans votre logement, combien y a-t-il d\'étages  ?': 'nombre_etages_logement',
        'Quelle est la surface de votre logement ?': 'surface_logement',
        'Merci de préciser la surface exacte si vous la connaissez': 'surface_exacte_logement',
        'Combien avez-vous de pièces dans votre logement ?': 'nombre_pieces_logement',
        'Y a-t-il des escaliers à l\'intérieur de votre logement ?': 'escaliers_interieur',
        'Y a-t-il des escaliers à l\'extérieur de votre logement ?': 'escaliers_exterieur',
        'Votre logement dispose-t-il d\'un grenier ?': 'grenier',
        'Votre logement dispose-t-il d\'une cave ?': 'cave',
        'Votre logement dispose-t-il d\'un ou plusieurs balcons ?': 'balcon',
        'De quel type est le chauffage principal de votre logement ?': 'type_chauffage_principal',
        'Quelles sont les sources d\'énergie du chauffage de votre logement ?': 'sources_energie_chauffage',
        'De quel(s) appareils de chauffage disposez-vous ?': 'appareils_chauffage',
        'Êtes-vous équipés de détecteur de fumée ?': 'detecteur_fumee',
        'Êtes-vous équipés de détecteur de monoxyde de carbone ?': 'detecteur_monoxyde_carbone',
        'Êtes-vous équipés d\'extincteur dans votre logement ?': 'extincteur',
        'Disposez-vous d\'un box ou d\'un garage/box ?': 'box_garage',
        'Disposez-vous d’un espace extérieur (jardin, terrain, cour…)  ?': 'espace_exterieur',
        'Quelle est la surface de cet espace extérieur ?': 'surface_espace_exterieur',
        'Merci de préciser la surface exacte si vous la connaissez_1': 'surface_exacte_espace_exterieur',
        'Avez-vous un abri ou une cabane de jardin ?': 'abri_cabane_jardin',
        'Y a -t-il un plan d\'eau et/ou une piscine dans votre espace extérieur ?': 'plan_eau_piscine',
    }

    # Renommer les colonnes du DataFrame
    df1 = df1.rename(columns=noms_colonnes)

    #_________________________________________________________________________________________________________________________

    # Extraction des 4 derniers caractères pour obtenir l'année de naissance
    df1['annee_naissance'] = df1['annee_naissance'].astype(str).str[-4:]
    df1 = df1[df1['annee_naissance'] != "2023"]  # Exclut l'année 2023

    #_________________________________________________________________________________________________________________________

    # Supprime les lignes où la colonne "date_remplissage" contient "Non complété"
    df1 = df1[df1['date_remplissage'] != "Non complété"]

    #_________________________________________________________________________________________________________________________

    # Remplit les valeurs manquantes de la colonne "profession_actuelle" avec "Étudiant"
    df1['profession_actuelle'] = df1['profession_actuelle'].fillna("Étudiant")

    #_________________________________________________________________________________________________________________________

    # Convertit les chaînes JSON en listes de dictionnaires pour la colonne "activites_sportives"
    df1['activites_sportives'] = df1['activites_sportives'].fillna('[]').astype(str).apply(safe_json_loads)

    # Applique la fonction de flattening pour transformer les données JSON en colonnes
    activites_df1 = df1['activites_sportives'].apply(lambda x: flatten_json_list(x, prefix="activite"))

    # Fusionne les nouvelles colonnes avec le DataFrame d'origine
    df1 = pd.concat([df1.drop(columns=['activites_sportives']), activites_df1], axis=1)

    #_________________________________________________________________________________________________________________________

    # Convertit les chaînes JSON en listes de dictionnaires pour la colonne "types_accidents"
    df1['types_accidents'] = df1['types_accidents'].fillna('[]').astype(str).apply(safe_json_loads)

    # Applique la fonction de flattening pour transformer les données JSON en colonnes
    accidents_df1 = df1['types_accidents'].apply(lambda x: flatten_json_list(x, prefix="accident"))

    # Fusionne les nouvelles colonnes avec le DataFrame d'origine
    df1 = pd.concat([df1.drop(columns=['types_accidents']), accidents_df1], axis=1)

    #_________________________________________________________________________________________________________________________

    # Convertit les chaînes JSON en listes de dictionnaires pour la colonne "personnes_dans_foyer"
    df1['personnes_dans_foyer'] = df1['personnes_dans_foyer'].fillna('[]').astype(str).apply(json.loads)

    # Applique la fonction de flattening pour transformer les données JSON en colonnes
    foyer_df1 = df1['personnes_dans_foyer'].apply(lambda x: flatten_json_list(x, prefix="personne"))

    # Fusionne les nouvelles colonnes avec le DataFrame d'origine
    df1 = pd.concat([df1.drop(columns=['personnes_dans_foyer']), foyer_df1], axis=1)

    #_________________________________________________________________________________________________________________________

    # Nettoie la colonne "taille_cm" en convertissant les valeurs en numérique
    df1['taille_cm'] = pd.to_numeric(df1['taille_cm'], errors='coerce')  # Convertit en numérique
    df1.loc[(df1['taille_cm'] > 1) & (df1['taille_cm'] <= 2.5), 'taille_cm'] *= 100  # Convertit les mètres en cm
    df1 = df1[df1['taille_cm'] > 100]  # Supprime les valeurs <= 100 cm

    #_________________________________________________________________________________________________________________________

    # Vérifie que les codes postaux contiennent bien 5 chiffres
    df1 = df1[df1['code_postal'].notna()]  # Supprime les lignes avec des NaN
    df1['code_postal'] = df1['code_postal'].astype(int)
    df1 = df1[(df1['code_postal'].astype(str).str.len() == 5) | (df1['code_postal'].astype(str).str.len() == 4)]  # Garde uniquement les codes postaux valides

    #_________________________________________________________________________________________________________________________

    # Nettoie la colonne "pays_naissance" en supprimant les accents et en uniformisant le format
    df1['pays_naissance'] = df1['pays_naissance'].apply(lambda x: unidecode(x) if isinstance(x, str) else x)
    df1['pays_naissance'] = df1['pays_naissance'].str.replace('-', ' ', regex=True)  # Remplace les tirets par des espaces
    df1['pays_naissance'] = df1['pays_naissance'].str.capitalize()  # Met en majuscule la première lettre

    #_________________________________________________________________________________________________________________________

    # Parcourt toutes les colonnes pour convertir les valeurs float en string si elles sont des entiers
    for col in df1.columns:
        for i in range(len(df1[col])):
            value = df1[col].iloc[i]  # Utilise .iloc pour accéder aux valeurs par position
            if isinstance(value, float) and value.is_integer():
                df1.at[df1.index[i], col] = str(int(value))  # Modifie la valeur directement

    #_________________________________________________________________________________________________________________________

    # Supprime les doublons dans la colonne "numero_volontaire"
    df1 = df1.drop_duplicates(subset=['numero_volontaire'])

    #_________________________________________________________________________________________________________________________

    # Remplace les sauts de ligne par des virgules dans tout le DataFrame
    df1 = df1.replace(r'\n', ', ', regex=True)

    return df1  # Retourne le DataFrame nettoyé

# Fonction principale pour nettoyer un DataFrame contenant des informations sur les accidents
def nettoyer_dataframe_accident(df2):
    # Fonction pour charger des chaînes JSON en toute sécurité
    def safe_json_loads(x):
        try:
            return json.loads(x)  # Tente de charger la chaîne JSON
        except (json.JSONDecodeError, TypeError):
            return []  # Retourne une liste vide en cas d'erreur

    # Fonction pour extraire les informations sur les accidents
    def extraire_accident(liste):
        resultat = {}
        for i, accident in enumerate(liste):  # Parcourt chaque accident dans la liste
            type_acc = accident.get("Type d'accident", None)  # Récupère le type d'accident
            detail_acc = accident.get("Type précis", None)  # Récupère les détails de l'accident
            resultat[f'accident_{i+1}_type'] = type_acc
            resultat[f'accident_{i+1}_precis'] = detail_acc
        return pd.Series(resultat)  # Retourne les données sous forme de Series pandas

    # Fonction pour extraire les informations sur les blessures
    def extraire_blessure(liste):
        resultat = {}
        for i, blessure in enumerate(liste):  # Parcourt chaque blessure dans la liste
            type_ble = blessure.get("Blessure", None)  # Récupère le type de blessure
            loc_ble = blessure.get("Localisation", None)  # Récupère la localisation de la blessure
            detail_loc = blessure.get("Localisation détaillée", None)  # Récupère les détails de localisation
            resultat[f'blessure_{i+1}_type'] = type_ble
            resultat[f'location_blessure_{i+1}'] = loc_ble
            resultat[f'location_precise_{i+1}'] = detail_loc
        return pd.Series(resultat)  # Retourne les données sous forme de Series pandas

    # Dictionnaire pour renommer les colonnes du DataFrame
    noms_colonnes = {
        # Exemple : "VOLONTAIRE N°" devient "ID"
        "VOLONTAIRE N°": "ID",
        "ANNEE DE NAISSANCE": "Annee_Naissance",
        "GENRE": "Genre",
        # Ajout de nombreuses autres colonnes pour uniformiser les noms
        "DATE DE REMPLISSAGE": "Date_Remplissage",
        "Dans les deux dernier mois, avez-vous été victime d'un accident de la vie courante ?": "Accident_2_Mois",
        "À quelle date a eu lieu l'accident de la vie courante ?": "Date_Accident",
        "À quelle heure ?": "Heure_Accident",
        "Un tiers est-il partiellement ou entièrement responsable de l'accident ?": "Responsable_Tiers",
        "Dans quel état de fatigue vous sentiez-vous au moment de l'accident ?": "Etat_Fatigue",
        "Quel est le code postal du lieu de l'accident ?  ": "Code_Postal_Accident",
        "Sélectionnez la commune de l'accident": "Commune_Accident",
        "Où a eu lieu l'accident ?": "Lieu_Accident",
        "Précisez le lieu de l'accident :": "Lieu_Accident_Precision",
        "Précisez le lieu de l'accident :_1": "Lieu_Accident_Precision_1",
        "Précisez le lieu de l'accident :_2": "Lieu_Accident_Precision_2",
        "Précisez le lieu de l'accident :_3": "Lieu_Accident_Precision_3",
        "Précisez le lieu de l'accident :_4": "Lieu_Accident_Precision_4",
        "Précisez le lieu de l'accident :_5": "Lieu_Accident_Precision_5",
        "Précisez le lieu de l'accident :_6": "Lieu_Accident_Precision_6",
        "Précisez le lieu de l'accident :_7": "Lieu_Accident_Precision_7",
        "Précisez le lieu de l'accident :_8": "Lieu_Accident_Precision_8",
        "Précisez le lieu de l'accident :_9": "Lieu_Accident_Precision_9",
        "Que faisiez-vous au moment de l'accident ?": "Activite_Accident",
        "Précisez l'activité pratiquée :": "Activite_Precision",
        "Quel sport pratiquiez-vous au moment de l'accident ?": "Sport_Accident",
        "Précisez le sport pratiqué :": "Sport_Precision",
        "De quel type d'accident s'agissait-il ?": "Type_Accident",
        "Dans quelle direction êtes-vous tombé(e) ?": "Direction_Chute",
        "Précisez d'où vous êtes tombée(e) :": "Origine_Chute",
        "Précisez par quoi (allergie, intoxication ou corrosion) : ": "Cause_Accident",
        "Le surmenage est-il arrivé au cours d'un :": "Contexte_Surmenage",
        "Vous êtes-vous blessé(e) dans l'accident ?": "Blesse",
        "Quelle(s) blessure(s) l'accident a-t-il provoqué ?": "Type_Blessure",
        "Avez-vous reçu des soins après l'accident ?": "Soins_Recus",
        "Par qui avez-vous reçu ces soins ?": "Fournisseur_Soins",
        "Combien de jours avez-vous été hospitalisé(e) ?": "Jours_Hospitalisation",
        "Êtes-vous toujours hospitalisé(e) ?": "Toujours_Hospitalise",
        "Avez-vous été en arrêt de travail suite à cet accident ?": "Arret_Travail",
        "Combien de jours (consécutifs) avez-vous été en arrêt de travail ?": "Jours_Arret_Travail",
        "Êtes-vous toujours en arrêt de travail ?": "Toujours_Arret_Travail",
        "Au cours des 48 heures qui ont suivi l'accident, avez-vous été limité(e) dans vos activités habituelles ?": "Limite_Activites_48h",
        "L'accident a-t-il entraîné un arrêt de la pratique de sport (entraînement ou compétition) ?": "Arret_Sport",
        "Combien de temps a duré cet arrêt de la pratique de sport ?": "Duree_Arret_Sport",
        "Êtes-vous toujours en arrêt de la pratique de sport ?": "Toujours_Arret_Sport",
        "Pouvez-vous décrire  en quelques mots le déroulement de l'accident et ses conséquences ?": "Description_Accident"
    }

    # Renommer les colonnes
    df2.rename(columns=noms_colonnes, inplace=True)

    # Supprime les colonnes inutiles
    if "Colonne1" in df2.columns:
        df2 = df2.drop("Colonne1", axis=1)
    df2 = df2.drop("Description_Accident", axis=1)

    # Ajoute une colonne pour indiquer si la ligne est valide
    df2['est_valide'] = True

    # Convertit la colonne "Annee_Naissance" en string et extrait les 4 derniers caractères
    df2['Annee_Naissance'] = df2['Annee_Naissance'].astype(str).str[-4:]
    df2 = df2[df2['Annee_Naissance'] != "2023"]  # Exclut l'année 2023

    # Convertit la colonne "Date_Remplissage" en datetime avec un format spécifique
    df2['Date_Remplissage'] = pd.to_datetime(
        df2['Date_Remplissage'], 
        format='%d-%m-%y %H:%M:%S', 
        errors='coerce'
    )

    # Marque les lignes où la conversion de date a échoué comme invalides
    df2['est_valide'] = df2['Date_Remplissage'].notna()

    # Condition pour vérifier si un accident a eu lieu dans les deux derniers mois
    condition = (df2['Accident_2_Mois'] == 'Oui')

    # Convertit la colonne "Code_Postal_Accident" en string et gère les valeurs manquantes
    df2['Code_Postal_Accident'] = df2['Code_Postal_Accident'].fillna(-1).astype(int).astype(str)
    df2.loc[df2['Code_Postal_Accident'] == '-1', 'Code_Postal_Accident'] = ''
    df2['Code_Postal_Accident'] = df2['Code_Postal_Accident'].str.zfill(5)

    # Vérifie la validité des codes postaux
    code_postal_str = df2.loc[condition, 'Code_Postal_Accident'].astype(str)
    cp_valide = code_postal_str.str.match(r'^\d{5}$')
    df2.loc[condition & ~cp_valide, 'est_valide'] = False
    df2['Code_Postal_Accident'] = df2['Code_Postal_Accident'].replace(["00000", "", "-1"], None)

    # Convertit les chaînes JSON en listes de dictionnaires pour la colonne "Type_Accident"
    df2['Type_Accident'] = df2['Type_Accident'].fillna('[]').astype(str).apply(safe_json_loads)

    # Applique la fonction de flattening pour transformer les données JSON en colonnes
    accident_df2 = df2['Type_Accident'].apply(extraire_accident)
    df2 = pd.concat([df2.drop(columns=['Type_Accident']), accident_df2], axis=1)

    # Convertit les chaînes JSON en listes de dictionnaires pour la colonne "Type_Blessure"
    df2['Type_Blessure'] = df2['Type_Blessure'].fillna('[]').astype(str).apply(safe_json_loads)

    # Applique la fonction de flattening pour transformer les données JSON en colonnes
    blessure_df2 = df2['Type_Blessure'].apply(extraire_blessure)
    df2 = pd.concat([df2.drop(columns=['Type_Blessure']), blessure_df2], axis=1)

    # Remplace certaines valeurs spécifiques dans la colonne "Lieu_Accident"
    df2.loc[df2['Lieu_Accident'] == "Habitat, dans mon propre foyer", 'Lieu_Accident'] = "Dans mon propre foyer"
    df2.loc[df2['Lieu_Accident'] == "Habitat, chez une autre personne", 'Lieu_Accident'] = "Chez une autre personne"

    # Convertit certaines colonnes en int et remplace les valeurs nulles par None
    for valeurs_float in ('Jours_Hospitalisation', 'Jours_Arret_Travail', 'Duree_Arret_Sport'):
        df2[valeurs_float] = df2[valeurs_float].fillna(0)
        df2[valeurs_float] = df2[valeurs_float].astype(int)
        df2[valeurs_float] = df2[valeurs_float].replace(0, None)

    # Supprime les doublons dans le DataFrame
    df2 = df2.drop_duplicates()

    # Filtre les lignes valides
    df2 = df2[df2["est_valide"] == True]

    return df2  # Retourne le DataFrame nettoyé