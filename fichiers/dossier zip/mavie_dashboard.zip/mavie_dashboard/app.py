import streamlit as st
import pandas as pd
from streamlit_option_menu import option_menu
from data_cleaning import nettoyer_dataframe_individu, nettoyer_dataframe_accident
from data_loader import charger_fichier
import base64
import scipy.stats as stats
import numpy as np
import matplotlib.pyplot as plt

st.set_page_config(
    page_title="Analyse Calyxis",
    page_icon="MAVIE.png",   
    layout="wide"
)

def get_image_base64(image_path):
    with open(image_path, "rb") as f:
        data = f.read()
    return base64.b64encode(data).decode()

image_base64 = get_image_base64("MAVIE.png")

st.markdown(
    f"""
    <style>
    body {{background-color: #ffffff;}}
    .main {{background-color: #ffffff;}}

    .stButton>button {{
        background-color:#0033cc;
        color:white;
        font-weight:bold;
        border:none;
        border-radius:10px;
        padding:0.6em 1em;
    }}

    .stDownloadButton>button {{
        background-color:#000000;
        color:#e6f0ff;
        font-weight:bold;
        border:2px solid #0033cc;
        border-radius:10px;
        padding:0.6em 1em;
    }}

    .stDownloadButton>button:hover {{
        background-color: #0033cc;
        color: white;
        border:2px solid #000000;
    }}

    code {{
        background-color: #e6f0ff;
        color: #0033cc;
        font-weight: bold;
        padding: 2px 6px;
        border-radius: 4px;
    }}
    </style>

    <a href="https://www.calyxis.fr/" target="_blank">
        <img src="data:image/png;base64,{image_base64}" width="170">
    </a>
    """,
    unsafe_allow_html=True
)

st.title("Observatoire MAVIE – Analyse des AcVC")



uploaded_file = st.file_uploader(
    "Importer un fichier Excel MAVIE", 
    type=["xlsx"],
    help="Le fichier doit contenir deux feuilles nommées correctement (individus + accidents) selon le format MAVIE."
)


if uploaded_file:
    try:
        individus, accidents = charger_fichier(uploaded_file)

        # Nettoyage d'abord
        individus_nettoyes = nettoyer_dataframe_individu(individus)
        accidents_nettoyes = nettoyer_dataframe_accident(accidents)

        # Vérification des colonnes essentielles après nettoyage
        colonnes_individus_attendues = ["numero_volontaire", "genre"]
        colonnes_accidents_attendues = ["ID", "Genre"]

        individus_ok = all(col in individus_nettoyes.columns for col in colonnes_individus_attendues)
        accidents_ok = all(col in accidents_nettoyes.columns for col in colonnes_accidents_attendues)

        if not individus_ok or not accidents_ok:
            st.error(
                "Le fichier ne contient pas les colonnes essentielles attendues après nettoyage.\n\n"
                "- Colonnes attendues dans les données des individus : `numero_volontaire`, `genre`\n"
                "- Colonnes attendues dans les données des accidents : `ID`, `Genre`\n\n"
                "Merci de vérifier la structure du fichier ou de vous assurer qu'il suit bien le modèle MAVIE."
            )
            st.stop()

    except Exception as e:
        st.error(f"Une erreur est survenue lors du chargement ou nettoyage des données : {e}")
        st.stop()


    with st.sidebar:
        st.markdown("""
        <style>
        .css-1d391kg, .css-1v0mbdj {
            background: #0033cc !important; /* bleu foncé */
            border-radius: 15px;
        }
        .css-17ziqus, .css-1lcbmhc {
            color: #fff !important; /* texte blanc */
        }
        </style>
        """, unsafe_allow_html=True)

        st.sidebar.caption("Navigation")

        selected = option_menu(
            menu_title="",
            options=["Accueil", "Individus", "Accidents", "Graphiques", "Solutions", "Tutoriel"],  # <--- ICI
            icons=["house", "table", "exclamation-triangle", "bar-chart", "lightbulb", "book"],   # <--- ICI (ex: "lightbulb" pour solution)
            menu_icon="cast",
            default_index=0,
            styles={
                "container": {"padding": "10px", "background-color": "#e6f0ff", "border-radius": "15px"},
                "icon": {"color": "#0033cc", "font-size": "20px"},
                "nav-link": {
                    "font-size": "18px",
                    "text-align": "left",
                    "margin": "4px",
                    "padding": "10px 16px",
                    "color": "#0033cc",
                    "border-radius": "10px"
                },
                "nav-link-selected": {
                    "background-color": "#0033cc",
                    "color": "white",
                    "font-weight": "bold"
                },
            }
        )


        genre_options = []
        colonnes_a_exporter = []
        colonnes_accident_export = []

        if selected == "Individus":
            genre_options = ["Tous"] + list(individus_nettoyes["genre"].dropna().unique())
            genre_filtre = st.selectbox("Filtrer par genre :", genre_options)
            st.markdown("**Colonnes à exporter :**")
            st.caption("Les colonnes sélectionnées seront visibles et incluses dans le fichier CSV téléchargé.")


            colonnes_a_exporter = st.multiselect(
                label="",
                options=list(individus_nettoyes.columns),
                help="Sélectionne les colonnes à afficher et exporter pour les individus."
            )

        elif selected == "Accidents":
            genre_options = ["Tous"] + list(accidents_nettoyes["Genre"].dropna().unique())
            genre_filtre = st.selectbox("Filtrer par genre :", genre_options)
            st.markdown("**Colonnes à exporter :**")
            st.caption("Les colonnes sélectionnées seront visibles et incluses dans le fichier CSV téléchargé.")

            colonnes_accident_export = st.multiselect(
                label="",
                options=list(accidents_nettoyes.columns),
                help="Sélectionne les colonnes à afficher et exporter pour les accidents."
            )

    if selected == "Accueil":
        st.markdown("## Tableau de bord global")

        # Bandeau d'accueil simple sans animation
        st.markdown("""
        <div style="background-color: #f5f8ff; padding: 20px 30px; border-radius: 12px; box-shadow: 0 2px 12px #00000011; margin-bottom: 25px;">
            <h2 style="color: #0033cc; margin-bottom: 10px;">Bienvenue dans l’Observatoire MAVIE</h2>
            <p style="color: #222; font-size: 1.05rem;">
                Ce tableau de bord interactif vous permet d’analyser les accidents de la vie courante (AcVC) à partir des données MAVIE.<br>
            </p>
        </div>
        """, unsafe_allow_html=True)

        # Statistiques principales
        col1, col2 = st.columns(2)
        with col1:
            st.markdown(f"""
            <div style="background-color:#f1f6ff;padding:24px 18px;border-radius:16px;box-shadow:0 2px 12px #0033cc22;">
                <h2 style="color:#0033cc;margin:0;font-size:2rem;">{len(individus_nettoyes)}</h2>
                <p style="color:#555;margin:0;font-size:1.1rem;">Total de lignes individus</p>
            </div>
            """, unsafe_allow_html=True)

        with col2:
            st.markdown(f"""
            <div style="background-color:#f1f6ff;padding:24px 18px;border-radius:16px;box-shadow:0 2px 12px #0033cc22;">
                <h2 style="color:#0033cc;margin:0;font-size:2rem;">{len(accidents_nettoyes)}</h2>
                <p style="color:#555;margin:0;font-size:1.1rem;">Total de lignes accidents</p>
            </div>
            """, unsafe_allow_html=True)

        st.subheader("Résumé statistique (KPIs)")
        try:
            age_moyen = int(individus_nettoyes["annee_naissance"].apply(lambda x: 2025 - int(x)).mean())
            nb_accidents_recents = accidents_nettoyes["Accident_2_Mois"].eq("Oui").sum()
            total_jours_hosp = accidents_nettoyes.loc[
                accidents_nettoyes["Accident_2_Mois"] == "Oui", "Jours_Hospitalisation"
            ].fillna(0).astype(int).sum()

            taux_hospitalisation = (total_jours_hosp / nb_accidents_recents) * 100 if nb_accidents_recents > 0 else 0

            col3, col4, col5 = st.columns(3)
            col3.metric("Âge moyen", f"{age_moyen} ans")
            col4.metric("Accidents récents", nb_accidents_recents)
            col5.metric("Taux hospitalisation", f"{taux_hospitalisation:.1f} %")
        except Exception as e:
            st.warning(f"Impossible de générer les indicateurs : {e}")
            

        st.markdown("## Test du Chi2 d’adéquation (cas de proportions)")

        with st.expander("Test d’adéquation sur une variable qualitative (ex : genre)", expanded=False):
            # Sélection de la table
            table_adequation = st.selectbox(
                "Sur quelles données veux-tu appliquer le test ?",
                ("Individus", "Accidents"),
                key="chi2_adequation_table_choice"
            )

            if table_adequation == "Individus":
                df_adequation = individus_nettoyes
            else:
                df_adequation = accidents_nettoyes

            # Liste des colonnes qualitatives (objet/string)
            colonnes_qualitatives_adequation = [col for col in df_adequation.columns if df_adequation[col].dtype == "object"]

            if len(colonnes_qualitatives_adequation) == 0:
                st.warning("Aucune variable qualitative disponible pour ce test.")
            else:
                var = st.selectbox("Variable à tester :", colonnes_qualitatives_adequation, key="chi2_adequation_var")

                # Valeurs observées
                effectifs_obs = df_adequation[var].value_counts().sort_index()
                n = effectifs_obs.sum()
                modalities = list(effectifs_obs.index)

                st.write("Effectifs observés :", effectifs_obs)

                # Saisie des proportions théoriques
                st.markdown("**Saisis les proportions théoriques attendues (%) pour chaque modalité :**")
                proportions_theoriques = []
                for mod in modalities:
                    val = st.number_input(
                        f"Proportion (%) attendue pour '{mod}' :",
                        min_value=0.0,
                        max_value=100.0,
                        value=100.0/len(modalities),
                        key=f"prop_{mod}_{table_adequation}_{var}"  # clef unique si on change de table/var
                    )
                    proportions_theoriques.append(val / 100.0)

                total_prop = sum(proportions_theoriques)
                # On attend 1.00 (soit 100% au total)
                if abs(total_prop - 1) > 0.01:
                    st.warning("⚠️ La somme des proportions ne fait pas 100% ! Corrige les valeurs.")
                else:
                    # Calcul des effectifs théoriques
                    effectifs_theo = [p * n for p in proportions_theoriques]
                    st.write("Effectifs théoriques :", dict(zip(modalities, np.round(effectifs_theo,2))))

                    # Test du chi2 d'adéquation
                    chi2_stat, p_val = stats.chisquare(f_obs=effectifs_obs, f_exp=effectifs_theo)
                    st.write(f"**Statistique du test :** {chi2_stat:.2f}")
                    st.write(f"**p-value :** {p_val:.4f}")

                    if p_val < 0.05:
                        st.success("Résultat : On rejette H0 au seuil de 5% → la distribution observée est différente de la théorie.")
                    else:
                        st.info("Résultat : On ne peut pas rejeter H0 au seuil de 5% → la distribution observée est compatible avec la théorie.")

                    # Camembert matplotlib
                    fig, ax = plt.subplots()
                    effectifs_obs.plot.pie(autopct="%.1f%%", startangle=90, ax=ax)
                    ax.set_ylabel("")
                    ax.set_title(f"Répartition observée de {var}")
                    st.pyplot(fig)



        st.markdown("## Test du Chi2 sur deux variables qualitatives")

        with st.expander("Test du Chi2 d'indépendance (sur Individus ou Accidents)", expanded=False):
            # Sélection de la table
            table_name = st.selectbox(
                "Sur quelles données veux-tu appliquer le test ?",
                ("Individus", "Accidents"),
                key="chi2_table_choice"
            )

            if table_name == "Individus":
                df = individus_nettoyes
            else:
                df = accidents_nettoyes

            # Liste des colonnes qualitatives de la table choisie
            colonnes_qualitatives = [col for col in df.columns if df[col].dtype == "object"]

            if len(colonnes_qualitatives) < 2:
                st.warning("Pas assez de variables qualitatives pour un test du Chi2 dans cette table.")
            else:
                var1 = st.selectbox("Variable 1 :", colonnes_qualitatives, key="chi2_var1")
                var2 = st.selectbox("Variable 2 :", colonnes_qualitatives, key="chi2_var2")
                if var1 and var2 and var1 != var2:
                    # Table de contingence
                    table = pd.crosstab(df[var1], df[var2])
                    st.write("Table de contingence :", table)
                    # Test du chi2
                    chi2, p, dof, expected = stats.chi2_contingency(table)
                    st.write(f"**Statistique du test :** {chi2:.2f}")
                    st.write(f"**p-value :** {p:.4f}")
                    if p < 0.05:
                        st.success("Résultat : Les variables NE SONT PAS indépendantes au seuil de 5% (on rejette H0).")
                    else:
                        st.info("Résultat : On NE PEUT PAS rejeter l'indépendance des variables au seuil de 5% (H0 non rejetée).")
                else:
                    st.info("Sélectionne deux variables qualitatives différentes pour réaliser le test.")


    elif selected == "Individus":
        st.subheader("Données individuelles")
        st.info("Affiche les informations des volontaires nettoyées. Utilise les filtres pour ajuster la vue ou exporter un sous-ensemble.")

        filtered_individus = individus_nettoyes.copy()
        if genre_options and genre_filtre != "Tous":
            filtered_individus = filtered_individus[filtered_individus["genre"] == genre_filtre]
        export_data = filtered_individus[colonnes_a_exporter] if colonnes_a_exporter else filtered_individus
        st.dataframe(export_data.head(30))
        st.download_button(
            label="Télécharger CSV – Individus",
            data=export_data.to_csv(index=False, encoding="utf-8-sig"),
            file_name="individus.csv",
            mime="text/csv"
        )

    elif selected == "Accidents":
        st.subheader("Analyse des accidents")
        st.info("Consulte les données nettoyées des accidents déclarés. Filtre par genre ou choisis les colonnes à exporter.")

        filtered_accidents = accidents_nettoyes.copy()
        if genre_options and genre_filtre != "Tous":
            filtered_accidents = filtered_accidents[filtered_accidents["Genre"] == genre_filtre]
        export_accident_data = (
            filtered_accidents[colonnes_accident_export]
            if colonnes_accident_export else filtered_accidents
        )
        st.dataframe(export_accident_data.head(30))
        st.download_button(
            label="Télécharger CSV – Accidents",
            data=export_accident_data.to_csv(index=False, encoding="utf-8-sig"),
            file_name="accidents.csv",
            mime="text/csv"
        )

    elif selected == "Graphiques":
        st.subheader("Visualisations Power BI")
        st.markdown(
            """
            Vous pouvez consulter les visualisations Power BI via deux options :

            1. **Accès en ligne sécurisé** (nécessite un compte Microsoft autorisé)  
            [Ouvrir le rapport Power BI](https://app.powerbi.com/reportEmbed?reportId=0aad950c-cb58-4a25-8297-c54e9568d158&autoAuth=true&ctid=7a5b8688-1490-4476-bc02-15fd2851531d)

            2. **Téléchargement local** du fichier `.pbix` si vous souhaitez l’ouvrir avec Power BI Desktop.
            """
        )

        try:
            with open("rapport_powerbi.pbix", "rb") as file:
                st.download_button(
                    label="Télécharger et ouvrir dans Power BI Desktop",
                    data=file,
                    file_name="rapport_powerbi.pbix",
                    mime="application/octet-stream"
                )
        except FileNotFoundError:
            st.warning("Le fichier 'rapport_powerbi.pbix' n'a pas été trouvé dans le dossier de l'application.")

        st.info("Une fois téléchargé, ouvrez le fichier avec Power BI Desktop pour consulter ou modifier les visualisations.")

    elif selected == "Solutions":
        st.subheader("Analyse des risques et mesures de prévention innovantes")

        st.markdown("""
        ### 1. Étages élevés et logements exigus

        Les victimes d’AcVC vivent plus souvent au troisième étage ou plus et dans des logements de petite surface (< 60 m²). L’exposition aux escaliers, au manque d’espace de circulation et à des aménagements inadaptés augmente fortement le risque de chute, notamment chez les personnes âgées.

        **Mesures de prévention :**
        - Sécurisation obligatoire des cages d’escaliers (barres d’appui, nez de marche antidérapants).
        - Priorisation des logements en rez-de-chaussée pour les publics fragiles.
        - Diagnostic “sécurité logement” gratuit pour les surfaces inférieures à 60 m².

        ---

        ### 2. Zones résidentielles à densité moyenne

        Les communes de 5 000 à 30 000 habitants concentrent une part importante des victimes, davantage que les zones rurales ou urbaines denses.

        **Mesures de prévention :**
        - Campagnes de prévention ciblées dans les villes moyennes (CCAS, maisons de quartier).
        - Déploiement de médiateurs santé-prévention dans les territoires faiblement médicalisés.
        - Cartographie locale des zones à intervention prioritaire.

        ---

        ### 3. Sexe et comportements à risque

        Les hommes représentent une part plus importante des victimes, alors qu’ils sont minoritaires chez les non-victimes. Ce constat appelle à des actions genrées.

        **Mesures de prévention :**
        - Modules de prévention adaptés au public masculin, en entreprise ou dans les clubs sportifs.
        - Formation express aux gestes d’urgence et aux risques domestiques courants.

        ---

        ### 4. Consommation d’alcool

        Les victimes consomment de l’alcool de façon plus régulière. Une fréquence de 2 à 4 fois par semaine est fortement corrélée à l’accidentologie.

        **Mesures de prévention :**
        - Auto-diagnostics anonymes de la consommation via application mobile.
        - Campagnes de réduction des risques ciblées dans les zones à forte consommation.
        - Accompagnement renforcé pour les personnes isolées avec consommation élevée.

        ---

        ### 5. Isolement et structure familiale

        Les personnes vivant seules sont surreprésentées parmi les victimes, contrairement aux couples sans enfants. Le manque de relais en cas d’urgence est un facteur aggravant.

        **Mesures de prévention :**
        - Mise en place de dispositifs de téléassistance financés partiellement par les collectivités.
        - Réseaux d’entraide de voisinage ou groupes de vigilance résidentielle.
        - Visites à domicile régulières pour les personnes seules de plus de 60 ans.

        ---

        ### 6. Revenus modestes

        Les ménages disposant de moins de 1500 € par mois ou refusant de répondre sont davantage victimes, ce qui montre l’effet des inégalités sociales sur la prévention.

        **Mesures de prévention :**
        - Subvention ou prêt gratuit de kits sécurité (tapis antidérapants, veilleuses, détecteurs).
        - Chèques prévention distribués par les CCAS pour les foyers sous un certain seuil de revenu.
        - Interventions de techniciens bénévoles ou services civiques pour l’adaptation rapide du domicile.

        ---

        ### 7. Nature et lieu des accidents

        Les chutes représentent 60 % des AcVC. Elles surviennent principalement à domicile, notamment lors des activités domestiques ou de déplacement intérieur.

        **Mesures de prévention :**
        - Ateliers “prévention des chutes” organisés dans les maisons de santé et les EHPAD.
        - Rénovation des sols glissants ou mal fixés (aides publiques).
        - Formation aux bons gestes dans les tâches ménagères, pour tous les âges.

        ---

        ### 8. Équipements de sécurité

        Si les détecteurs de fumée sont largement présents, seuls 18 % des foyers possèdent un détecteur de monoxyde et 23 % un extincteur.

        **Mesures de prévention :**
        - Généralisation progressive des équipements obligatoires avec appui financier.
        - Sensibilisation à l’usage correct des extincteurs (tutoriels ou ateliers).
        - Distribution d’un pack sécurité dans les zones à forte densité d’accidents.

        ---

        ### 9. Statut professionnel et inactivité

        Les personnes inactives représentent près de 65 % des victimes, alors qu’elles sont moins présentes dans la population générale. Le temps passé à domicile, le manque d’activité physique et la solitude sont des facteurs aggravants.

        **Mesures de prévention :**
        - Activités régulières proposées aux retraités : marche encadrée, routines physiques, jeux de mémoire.
        - Intégration de la prévention domestique dans les parcours d’insertion ou de retraite.
        - Sensibilisation dans les structures sociales et les mutuelles.

        ---

        ### Conclusion

        Les accidents de la vie courante sont le résultat d’un enchevêtrement de facteurs : âge, isolement, logement, habitudes de vie, ressources disponibles. Les données observées confirment qu’il **n’existe pas un seul profil type de victime**, mais plusieurs formes de vulnérabilités qui se combinent.

        La prévention doit donc :
        - Être **ciblée**, en fonction du profil et de l’environnement de la personne.
        - Être **accessible**, via des aides techniques et financières concrètes.
        - Être **continue**, grâce à des dispositifs de suivi et de rappel.

        Un outil numérique d’aide à la prévention, basé sur ces données, peut guider les citoyens vers les bons gestes, les bons équipements et les bonnes ressources, au bon moment. Le croisement dynamique des facteurs personnels, environnementaux et comportementaux permet de bâtir une prévention **intelligente, sociale et équitable**.
        """)


    elif selected == "Tutoriel":
        st.subheader("Tutoriel de l’outil CALYXIS x MAVIE")
        st.markdown("""
        Cette application a été conçue pour faciliter l'analyse des données issues de l'étude MAVIE (accidents de la vie courante).  
        Elle transforme un fichier Excel brut contenant les déclarations des volontaires en une interface claire, interactive et prête à l’analyse.

        ### Objectif de l'outil  
        - Fournir un diagnostic rapide, fiable et visuel des jeux de données MAVIE  
        - Rendre leur traitement accessible, même à un utilisateur non technique  

        ### Fonctionnalités disponibles

        1. **Importation intelligente des données**  
            - Import d’un fichier `.xlsx` structuré (conforme au modèle MAVIE)  
            - Détection automatique des feuilles `Individus` et `Accidents`  
            - Vérification de la présence de colonnes clés (`ID`, `numero_volontaire`, `genre`...)  
            - Message d’erreur explicite si le format est incorrect  

        2. **Nettoyage automatisé et structuré**  
            Un module Python applique automatiquement :  
            - Suppression des doublons  
            - Décodage des champs JSON imbriqués (ex. : sports, blessures)  
            - Uniformisation des noms de colonnes, gestion des accents et caractères spéciaux  
            - Correction des dates, tailles, booléens, etc.  
            - Gestion des données manquantes et incohérentes  

            Ces transformations sont invisibles mais essentielles à chaque importation.

        3. **Navigation ergonomique**  
            Le menu latéral vous permet d’accéder à 5 sections claires :  
            - Accueil : vue d’ensemble (statistiques clés)  
            - Individus : exploration filtrée des volontaires, export CSV  
            - Accidents : exploration filtrée des cas déclarés, export CSV  
            - Graphiques : lien vers les visualisations Power BI  
            - Tutoriel : cette documentation interactive  

        4. **Filtrage dynamique des données**  
            - Filtrage par genre (homme, femme, autre)  
            - Sélection manuelle des colonnes à afficher et exporter  

            Cela permet une analyse ciblée des variables pertinentes.

        5. **Exportation personnalisée en `.csv`**  
            - Export des données filtrées  
            - Encodage UTF-8-sig compatible Excel  
            - Noms de fichiers explicites selon la section (`individus.csv`, `accidents.csv`)  

        6. **Lien vers un rapport Power BI**  
            Deux options proposées :  
            - Lien sécurisé vers une version en ligne du rapport Power BI  
            - Téléchargement du fichier `.pbix` pour consultation dans Power BI Desktop  

            Le rapport Power BI permet des visualisations avancées : timelines, matrices, heatmaps…

        ### Limites actuelles

        - Les rapports Power BI ne peuvent pas être affichés directement dans l’application (iframe désactivée côté Power BI).
        - L’application est conçue pour des fichiers bien structurés. Si les colonnes ou feuilles sont manquantes ou renommées, l’import échoue.
        - Pas encore de système de tests automatisés pour les gros volumes de données (au-delà de 10 000 lignes).
        - **L’option Publish to Web n’est pas disponible pour les cartes ArcGIS for Power BI :** il n’est donc pas possible d’intégrer les cartes en ligne dans l’application ; pour consulter l’ensemble des visualisations cartographiques, il faut télécharger et ouvrir le fichier `.pbix` dans Power BI Desktop.


        ### Démarche de test appliquée

        - Import de plusieurs fichiers MAVIE (`MAVIE_BD_SD_mai_2025.xlsx`, etc.)  
        - Vérification des résultats obtenus par comparaison avec le fichier de référence (`MAVIE_Questionnaires.xlsx`)  
        - Validation manuelle des exports `.csv` (vérification de l’encodage UTF-8 et des formats Excel)  
        - Lecture complète du fichier `.pbix` dans Power BI Desktop  

        ### Ressources disponibles

        - [Voir la vidéo explicative](https://youtu.be/0emjoYLXTRU)

        """, unsafe_allow_html=True)
else:
    st.info("Importe un fichier `.xlsx` pour commencer.")
