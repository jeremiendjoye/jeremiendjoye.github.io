library(sampling)  # Chargement du package nécessaire pour l'échantillonnage

# Importation des données depuis un fichier CSV
df <- read.csv2("population_francaise_communes.csv")

# Sélection des communes de la région "Pays de la Loire" avec uniquement les colonnes utiles
donnees <- df[df["Nom.de.la.région"] == "Pays de la Loire", c("Code.département", "Commune", "Population.totale")]

# Conversion de la variable Population.totale en numérique (suppression des espaces éventuels)
donnees$Population.totale <- as.numeric(gsub(" ", "", donnees$Population.totale))

# Affichage des 6 premières lignes du jeu de données filtré
head(donnees)

# La variable U contient la liste de toutes les communes du Pays de la Loire
U <- donnees$Commune
head(U)

# Calcul du nombre total de communes
N <- length(U)
N

# Calcul de la population totale T du Pays de la Loire
T <- sum(donnees$Population.totale) 
T

# Tirage aléatoire simple de n = 100 communes
n = 100
E <- sample(U, n)
head(E)

# Extraction des données correspondant aux 100 communes tirées
donnees1 <- donnees[donnees$Commune %in% E, ]
head(donnees1)  # Affichage des 6 premières lignes

# Création d’un nouveau DataFrame avec uniquement la commune et la population
donnees2 <- subset(donnees1, select = c(Commune, Population.totale))
head(donnees2)

# Calcul de la moyenne de la population sur l’échantillon
xbar <- mean(donnees2$Population.totale)
xbar

# Calcul d’un intervalle de confiance à 95 % pour la moyenne (mu)
idcmoy <- t.test(donnees2$Population.totale)$conf.int
idcmoy

# Estimation de la population totale du Pays de la Loire à partir de l’échantillon
T_test <- N * xbar
T_test

# Intervalle de confiance pour l’estimation de la population totale
idcT <- idcmoy * N
idcT

# Calcul de la marge d’erreur associée à l’estimation
marge = (idcT[2] - idcT[1]) / 2
marge



# ----------------------------------------------------------------------------------------------------------------------------------------------------------------

# Echantillonnage aléatoire stratifié

# Obtention des quartiles grâce à summary ( d'où les chiffres ci-dessous)
summary(donnees$Population.totale)


# strates : <525, entre 525 et 1173, entre 1173 et 2719, plus de 2719

donnees$strate=cut(donnees$Population.totale, breaks=c(0,525, 1173, 2719, Inf), labels=c(1,2,3,4))
donneesstrat=donnees[ ,c("Commune", "Population.totale", "strate")]
head(donneesstrat)

#2. Tirer, selon un sondage stratifié, un echantillon E de taille n = 100 de communes, 
#en prenant des effectifs dans les strates proportionnels aux poids des strates.
data = donneesstrat[order(donneesstrat$strate), ]
head(data)

# effectif des strates
Nh=table(data$strate)
Nh
N=sum(Nh)
N

# Poids des strates
gh=Nh/N
gh

# Tirage d’un echantillon stratifié de taille n=100
n=100
nh=round(c(n*Nh[1]/N, n*Nh[2]/N, n*Nh[3]/N, n*Nh[4]/N))
nh

# taux de sondage dans les strates (on peut assimiler ce tirage sans remise à un tirage avec remise)
fh=nh/Nh
fh
# sondage strat (sans remise dans les strates)
st = strata(data, stratanames = c("strate"), size = nh, method = "srswr")
data1=getdata(data, st)
head(data1)
length((data1$Commune))

# Définir les 4 sous échantillons obtenus. Calculer les moyennes estimées des strates et leurs variances.
ech1=data1[data1$strate==1, ]
ech1
ech2=data1[data1$strate==2, ]
ech3=data1[data1$strate==3, ]
ech4=data1[data1$strate==4, ]

# Moyennes des 4 sous-echantillons
m1=mean(ech1$Population.totale)
m2=mean(ech2$Population.totale)
m3=mean(ech3$Population.totale)
m4=mean(ech4$Population.totale)

# Variances des 4 sous-echantillons
var1=var(ech1$Population.totale)
var2=var(ech2$Population.totale)
var3=var(ech3$Population.totale)
var4=var(ech4$Population.totale)

#Estimation X barre
#st du nombre d’habitants moyen µ et une estimation de la variance de X barre

# Moyenne des 4 echant reunis
Xbarst= (Nh[1]*m1 + Nh[2]*m2 + Nh[3]*m3 + Nh[4]*m4)/N
# estimation de la variance de Xbarst
varXbarst= ((gh[1])^2)*(1-fh[1])*var1/(nh[1]) + ((gh[2])^2)*(1-fh[2])*var2/(nh[2]) +
  ((gh[3])^2)*(1-fh[3])*var3/(nh[3]) + ((gh[4])^2)*(1-fh[4])*var4/(nh[4])

# idc pour mu à 95%
alpha=0.05
binf = Xbarst - qnorm(1-alpha/2)*sqrt(varXbarst)
bsup = Xbarst + qnorm(1-alpha/2)*sqrt(varXbarst)
idcmoy=c(binf, bsup)

#6.Estimation Tstr du nombre total d’habitants T, ainsi qu’un IDC pour T et sa marge d’erreur.

Tstr= N*Xbarst
Tstr
# Estimation par IDC du total T
binf = idcmoy[1]*N
bsup= idcmoy[2]*N

idcT=c(binf, bsup)
idcT

 # marge d’erreur
marge=(idcT[2]-idcT[1])/2
marge



