import mysql.connector
import tkinter as tk
from tkinter import messagebox, ttk, filedialog
import csv
from datetime import datetime


def convert_date(date_str):
    try:
        return datetime.strptime(date_str, "%d/%m/%Y").strftime("%Y-%m-%d")
    except ValueError:
        print(" Date invalide ignorée : " + date_str)
        return None  # Pour éviter d'insérer une mauvaise date

# Fonction pour charger les données d'une table
def charger_data(tableau, table_name):
    try:
        for ligne in tableau.get_children():
            tableau.delete(ligne)
        cursor.execute(f"SELECT * FROM {table_name}")
        for ligne in cursor.fetchall():
            tableau.insert("", "end", values=ligne)
    except mysql.connector.Error as err:
        messagebox.showerror("Erreur", f"Erreur lors du chargement des données : {err}")

# Fonction pour ajouter une ligne dans une table
def ajout_ligne(table_name, entries, tableau):
    try:
        # Récupérer les valeurs des widgets tk.Entry
        values = [entry.get() for entry in entries.values()]
        if any(not value for value in values):
            messagebox.showerror("Erreur", "Veuillez remplir tous les champs.")
            return
        placeholders = ", ".join(["%s"] * len(values))
        columns = ", ".join(entries.keys())
        query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
        cursor.execute(query, values)
        db.commit()
        charger_data(tableau, table_name)
    except mysql.connector.Error as err:
        messagebox.showerror("Erreur", f"Erreur lors de l'ajout de la ligne : {err}")

# Fonction pour supprimer une ligne sélectionnée dans une table
def supprimer_ligne(table_name, tableau, primary_key_column):
    try:
        selected_item = tableau.selection()
        if not selected_item:
            messagebox.showerror("Erreur", "Veuillez sélectionner une ligne à supprimer.")
            return
        item = tableau.item(selected_item)
        primary_key_value = item["values"][0]
        query = f"DELETE FROM {table_name} WHERE {primary_key_column} = %s"
        cursor.execute(query, (primary_key_value,))
        db.commit()
        charger_data(tableau, table_name)
    except mysql.connector.Error as err:
        messagebox.showerror("Erreur", f"Erreur lors de la suppression de la ligne : {err}")


def adding_from_a_file():
    # Fenêtre pour sélectionner la table
    file_window = tk.Toplevel()
    file_window.title("Ajouter des données à partir d'un fichier")
    taille_fenetre(file_window)
    ttk.Label(file_window, text="Sélectionnez une table :", font=("Arial", 14)).pack(pady=10)

    # Fonction pour charger le fichier CSV et insérer les données dans la table
    def insert_saunier():
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if not file_path:
            return
        try:
            with open(file_path, newline='', encoding='latin1') as file:  # Encodage latin1 pour lire le fichier
                reader = csv.reader(file, delimiter=";")
                next(reader)  # Ignorer l'en-tête du CSV
                inserted_count = 0  # Compteur pour suivre les éléments insérés

                for row in reader:
                    if len(row) < 4:
                        print("Ligne ignorée (colonnes manquantes) :", row)
                        continue
                    numSau, nomSau, prenomSau, villeSau = row
                    cursor.execute("SELECT COUNT(*) FROM saunier WHERE numSau = %s", (numSau,))
                    if cursor.fetchone()[0] == 0:
                        requete = "INSERT INTO saunier (numSau, nomSau, prenomSau, villeSau) VALUES (%s, %s, %s, %s)"
                        cursor.execute(requete, (numSau, nomSau, prenomSau, villeSau))
                        db.commit()
                        inserted_count += 1  # Incrémenter le compteur

                if inserted_count == 0:
                    messagebox.showinfo("Info", "Aucun élément ajouté. La table SAUNIER est à jour.")
                else:
                    messagebox.showinfo("Info", f"{inserted_count} élément(s) ajouté(s) dans la table SAUNIER.")

        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de l'insertion : {e}")

    def insert_client():
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if not file_path:
            return
        try:
            with open(file_path, newline='', encoding='utf-8') as file:
                reader = csv.reader(file, delimiter=";")
                next(reader)  # Ignorer l'en-tête du CSV
                inserted_count = 0  # Compteur pour suivre les éléments insérés

                for row in reader:
                    if len(row) < 4:
                        print("Ligne ignorée (colonnes manquantes) :", row)
                        continue
                    numCli, nomCli, precisionCli, villeCli = row
                    cursor.execute("SELECT COUNT(*) FROM client WHERE numCli = %s", (numCli,))
                    if cursor.fetchone()[0] == 0:
                        requete = "INSERT INTO client (numCli, nomCli, precisionCli, villeCli) VALUES (%s, %s, %s, %s)"
                        cursor.execute(requete, (numCli, nomCli, precisionCli, villeCli))
                        db.commit()
                        inserted_count += 1  # Incrémenter le compteur

                if inserted_count == 0:
                    messagebox.showinfo("Info", "Aucun élément ajouté. La table CLIENT est à jour.")
                else:
                    messagebox.showinfo("Info", f"{inserted_count} élément(s) ajouté(s) dans la table CLIENT.")

        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de l'insertion : {e}")

    def insert_entree():
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if not file_path:
            return
        try:
            with open(file_path, newline='', encoding='utf-8') as file:
                reader = csv.reader(file, delimiter=";")
                next(reader)  # Ignorer l'en-tête du CSV
                inserted_count = 0  # Compteur pour suivre les éléments insérés

                for row in reader:
                    if len(row) < 5:
                        print("Ligne ignorée (colonnes manquantes) :", row)
                        continue
                    numEnt, dateEnt, qteEnt, numPdt, numSau = row
                    dateEnt = convert_date(dateEnt)

                    cursor.execute("SELECT COUNT(*) FROM entree WHERE numEnt = %s", (numEnt,))
                    if cursor.fetchone()[0] == 0:
                        requete = "INSERT INTO entree (numEnt, dateEnt, qteEnt, numPdt, numSau) VALUES (%s, %s, %s, %s, %s)"
                        cursor.execute(requete, (numEnt, dateEnt, qteEnt, numPdt, numSau))
                        db.commit()
                        inserted_count += 1  # Incrémenter le compteur

                if inserted_count == 0:
                    messagebox.showinfo("Info", "Aucun élément ajouté. La table ENTREE est à jour.")
                else:
                    messagebox.showinfo("Info", f"{inserted_count} élément(s) ajouté(s) dans la table ENTREE.")

        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de l'insertion : {e}")

    def insert_sortie():
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if not file_path:
            return
        try:
            with open(file_path, newline='', encoding='utf-8') as file:
                reader = csv.reader(file, delimiter=";")
                next(reader)  # Ignorer l'en-tête du CSV (si nécessaire)

                sorties_insertees = set()  # Pour suivre les sorties déjà insérées

                for row in reader:
                    if len(row) < 5:
                        print("Ligne ignorée (colonnes manquantes) :", row)
                        continue

                    numSort = row[0]
                    dateSort = convert_date(row[1])
                    numCli = row[2]
                    numPdt = row[3]
                    qteSort = row[4]

                    # Insérer dans la table sortie si la combinaison (numSort, dateSort, numCli) n'a pas été insérée
                    sortie_key = (numSort)
                    if sortie_key not in sorties_insertees:
                        try:
                            sql = """INSERT INTO sortie (numSort, dateSort, numCli) VALUES (%s, %s, %s)"""
                            cursor.execute(sql, (numSort, dateSort, numCli))
                            db.commit()
                            sorties_insertees.add(sortie_key)
                        except mysql.connector.IntegrityError:
                            messagebox.showerror(f"L'entrée avec numSort {numSort} existe déjà dans la table sortie.")

                    # Vérifier que le couple numSort et numPdt n'existe pas déjà dans la table concerner
                    cursor.execute("SELECT COUNT(*) FROM concerner WHERE numSort = %s AND numPdt = %s", (numSort, numPdt))
                    if cursor.fetchone()[0] == 0:
                        # Requête SQL d'insertion dans la table concerner
                        requete = """INSERT INTO concerner (numSort, numPdt, qteSort) VALUES (%s, %s, %s)"""
                        cursor.execute(requete, (numSort, numPdt, qteSort))
                        db.commit()

        except mysql.connector.Error as err:
            messagebox.showerror("Erreur MySQL :", err)

    # Boutons pour chaque table
    ttk.Button(file_window, text="CLIENT", command=insert_client, width=30).pack(pady=5)
    ttk.Button(file_window, text="SAUNIER", command=insert_saunier, width=30).pack(pady=5)
    ttk.Button(file_window, text="SORTIE", command=insert_sortie, width=30).pack(pady=5)
    ttk.Button(file_window, text="ENTREE", command=insert_entree, width=30).pack(pady=5)

    # Bouton pour fermer la fenêtre
    ttk.Button(file_window, text="Retour", command=file_window.destroy, width=30).pack(pady=10)


def execute_query():
    query_window = tk.Toplevel()
    query_window.title("Exécuter une requête SQL")
    #taille_fenetre(query_window)
    query_window.geometry("800x800")
    
    # Label pour la saisie de la requête
    ttk.Label(query_window, text="Saisissez votre requête SQL :", font=("Arial", 12)).pack(pady=10)

    # Zone de texte pour saisir la requête
    query_text = tk.Text(query_window, height=10, width=70)
    query_text.pack(pady=10)

    # Cadre pour afficher les résultats
    result_frame = ttk.Frame(query_window)
    result_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

    # Tableau pour afficher les résultats
    result_tree = ttk.Treeview(result_frame, show="headings")
    result_tree.pack(fill=tk.BOTH, expand=True)

    # Fonction pour exécuter la requête
    def run_query():
        query = query_text.get("1.0", tk.END).strip()
        if not query:
            messagebox.showerror("Erreur", "Veuillez saisir une requête SQL.")
            return
        try:
            cursor.execute(query)
            if query.lower().startswith("select"):
                # Afficher les résultats dans le Treeview
                rows = cursor.fetchall()
                columns = [desc[0] for desc in cursor.description]
                result_tree["columns"] = columns
                for col in columns:
                    result_tree.heading(col, text=col)
                    result_tree.column(col, width=100)
                result_tree.delete(*result_tree.get_children())
                for row in rows:
                    result_tree.insert("", "end", values=row)
            else:
                # Exécuter une requête non-SELECT (INSERT, UPDATE, DELETE, etc.)
                db.commit()
                messagebox.showinfo("Succès", "Requête exécutée avec succès.")
        except mysql.connector.Error as err:
            messagebox.showerror("Erreur", f"Erreur lors de l'exécution de la requête : {err}")

    # Boutons pour exécuter et fermer
    button_frame = ttk.Frame(query_window)
    button_frame.pack(padx=10, pady=10)

    ttk.Button(button_frame, text="Exécuter", command=run_query, width=30).pack(side=tk.LEFT, padx=5)
    ttk.Button(button_frame, text="Retour", command=query_window.destroy, width=30).pack(side=tk.LEFT, padx=5)


def taille_fenetre(window):
    # Dimensions de l'écran
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()

    # Dimensions de la fenêtre (1/2 de l'écran)
    window_width = screen_width // 2
    window_height = screen_height // 2

    # Position pour centrer la fenêtre
    position_x = (screen_width - window_width) // 2
    position_y = (screen_height - window_height) // 2

    # Définir la taille et la position de la fenêtre
    window.geometry(f"{window_width}x{window_height}+{position_x}+{position_y}")

# Fonction pour ouvrir une fenêtre pour une table
def open_table_window(table_name, columns, headings, primary_key_column, modifier):
    table_window = tk.Toplevel()  # Utiliser Toplevel pour une nouvelle fenêtre
    table_window.title(f"Table: {table_name}")

    taille_fenetre(table_window)

    # Tableau pour afficher les données
    tableau = ttk.Treeview(table_window, columns=columns, show="headings")
    for col, heading in zip(columns, headings):
        tableau.heading(col, text=heading)
    tableau.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

    # Barre de recherche
    search_frame = ttk.Frame(table_window)
    search_frame.pack(fill=tk.X, padx=10, pady=5)

    ttk.Label(search_frame, text="Rechercher :").pack(side=tk.LEFT, padx=5)
    search_entry = ttk.Entry(search_frame)
    search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)

    def search_table():
        search_term = search_entry.get().strip()
        if not search_term:
            charger_data(tableau, table_name)  # Recharger toutes les données si le champ est vide
            return
        try:
            # Construire une requête SQL pour rechercher dans toutes les colonnes
            query = f"SELECT * FROM {table_name} WHERE " + " OR ".join(
                [f"{col} LIKE %s" for col in columns]
            )
            search_values = [f"%{search_term}%"] * len(columns)
            cursor.execute(query, search_values)
            rows = cursor.fetchall()

            # Effacer les données actuelles du tableau
            for ligne in tableau.get_children():
                tableau.delete(ligne)

            # Insérer les résultats de la recherche
            for row in rows:
                tableau.insert("", "end", values=row)
        except mysql.connector.Error as err:
            messagebox.showerror("Erreur", f"Erreur lors de la recherche : {err}")

    ttk.Button(search_frame, text="Rechercher", command=search_table).pack(side=tk.LEFT, padx=5)

    # Charger les données initiales
    charger_data(tableau, table_name)

    if modifier:
        # Cadre pour les champs d'entrée
        entry_frame = ttk.Frame(table_window)
        entry_frame.pack(fill=tk.X, padx=10, pady=10)

        # Créer un dictionnaire pour stocker les widgets tk.Entry
        entries = {}
        for i, col in enumerate(columns):
            ttk.Label(entry_frame, text=col).grid(row=0, column=i, padx=5, pady=5)
            entry = ttk.Entry(entry_frame)
            entry.grid(row=1, column=i, padx=5, pady=5)
            entries[col] = entry  # Associer le nom de la colonne au widget tk.Entry

    # Boutons pour ajouter et supprimer des lignes
    action_frame = ttk.Frame(table_window)
    action_frame.pack(fill=tk.X, padx=10, pady=10)

    if modifier:
        ttk.Button(action_frame, text="Ajouter", command=lambda: ajout_ligne(table_name, entries, tableau)).pack(side=tk.LEFT, padx=5)
        ttk.Button(action_frame, text="Supprimer", command=lambda: supprimer_ligne(table_name, tableau, primary_key_column)).pack(side=tk.LEFT, padx=5)

    # Bouton pour revenir au menu principal
    def return_to_menu():
        table_window.destroy()

    ttk.Button(action_frame, text="Retour", command=return_to_menu).pack(side=tk.LEFT, padx=5)


# Fonction pour ouvrir la fenêtre menu des tables
def open_tablemenu_window(modifier=False):
    table_window = tk.Toplevel()
    table_window.title("Menu Tables")

    taille_fenetre(table_window)

    ttk.Label(table_window, text="Sélectionnez une table à afficher :", font=("Arial", 14)).pack(pady=10)

    # Cadre pour organiser les boutons en grille 2x3
    button_frame = ttk.Frame(table_window)
    button_frame.pack(pady=20)

    buttons = [
        ("CLIENT", lambda: open_table_window("CLIENT", 
            ["numCli", "nomCli", "precisionCli", "villeCli"], 
            ["Numéro Client", "Nom Client", "Précision", "Ville"], 
            "numCli", modifier)),
        ("SAUNIER", lambda: open_table_window("SAUNIER", 
            ["numSau", "nomSau", "prenomSau", "villeSau"], 
            ["Numéro Saunier", "Nom Saunier", "Prénom Saunier", "Ville"], 
            "numSau", modifier)),
        ("PRODUIT", lambda: open_table_window("PRODUIT", 
            ["numPdt", "libPdt", "stockPdt"], 
            ["Numéro Produit", "Libellé Produit", "Stock"], 
            "numPdt", modifier)),
        ("SORTIE", lambda: open_table_window("SORTIE", 
            ["numSort", "dateSort", "numCli"], 
            ["Numéro Sortie", "Date Sortie", "Numéro Client"], 
            "numSort", modifier)),
        ("ENTREE", lambda: open_table_window("ENTREE", 
            ["numEnt", "dateEnt", "qteEnt", "numSau", "numPdt"], 
            ["Numéro Entrée", "Date Entrée", "Quantité Entrée", "Numéro Saunier", "Numéro Produit"], 
            "numEnt", modifier)),
        ("COUTER", lambda: open_table_window("COUTER", 
            ["numPdt", "annee", "prixAchat", "prixVente"], 
            ["Numéro Produit", "Année", "Prix Achat", "Prix Vente"], 
            "numPdt", modifier)),
    ]

    for i, (text, command) in enumerate(buttons):
        row, col = divmod(i, 3)
        ttk.Button(button_frame, text=text, command=command).grid(row=row, column=col, padx=10, pady=10)

    # Bouton pour revenir au menu principal
    def return_to_menu():
        table_window.destroy()

    if not modifier:
        ttk.Button(table_window, text="Retour", command=return_to_menu).pack(pady=10)
    else:
        ttk.Button(table_window, text="Retour", command=return_to_menu).pack(pady=10)

    table_window.mainloop()

# Fonction pour ouvrir la fenêtre "Modifier les Tables"
def open_modif_window():
    modif_window = tk.Toplevel()  # Nouvelle fenêtre
    modif_window.title("Modifier les Tables")

    taille_fenetre(modif_window)

    ttk.Label(modif_window, text="Modifier les Tables", font=("Arial", 16)).pack(pady=20)

    # Cadre pour organiser les boutons
    button_frame = ttk.Frame(modif_window)
    button_frame.pack(pady=20)

    # Boutons avec taille ajustée
    ttk.Button(button_frame, text="Modifier à partir des tables", command=lambda: open_tablemenu_window(True), 
               width=35).pack(pady=10)
    ttk.Button(button_frame, text="Modifier à partir d'un fichier CSV", command=lambda: adding_from_a_file(), 
               width=35).pack(pady=10)
    ttk.Button(button_frame, text="Modifier à partir d'un fichier SQL", command=lambda: open_data_sql_file_window(), 
               width=35).pack(pady=10)
    ttk.Button(button_frame, text="Modifier à partir d'une requête SQL", command=lambda: execute_query(), 
               width=35).pack(pady=10)

    # Bouton pour revenir au menu principal
    def return_to_menu():
        modif_window.destroy()

    ttk.Button(modif_window, text="Retour", command=return_to_menu, width=30).pack(pady=20)

# Fonction pour ouvrir la fenêtre principale "Menu"
def open_menu_window():
    close_all_windows()  # Fermer toutes les fenêtres Tkinter
    menu_window = tk.Tk()  # La fenêtre principale reste une instance de Tk
    menu_window.title("Menu Principal")

    taille_fenetre(menu_window)

    ttk.Label(menu_window, text="Accès base de donnée sel marin", font=("Arial", 16)).pack(pady=20)

    # Bouton centré
    ttk.Button(menu_window, text="Afficher les tables", command=lambda: open_tablemenu_window(), 
               width=30).pack(pady=20)

    ttk.Button(menu_window, text="Modifier les tables", command=lambda: open_modif_window(), 
               width=30).pack(pady=20)
    
    ttk.Button(menu_window, text="Exécuter les requêtes", command=lambda: open_query_buttons_window(), 
               width=30).pack(pady=20)

    menu_window.mainloop()


def open_query_buttons_window():
    query_buttons_window = tk.Toplevel()
    query_buttons_window.title("Exécuter des Requêtes Pré-définies")

    taille_fenetre(query_buttons_window)

    ttk.Label(query_buttons_window, text="Sélectionnez une requête à exécuter :", font=("Arial", 14)).pack(pady=10)

    # Liste des requêtes pré-définies (à personnaliser)
    queries = [
        """SELECT CLIENT.nomCli, CLIENT.precisionCli, CLIENT.villeCli, SUM(CONCERNER.qteSort) As qteAchatFleurDeSelenT
        FROM CLIENT 
        JOIN SORTIE ON CLIENT.numCli = SORTIE.numCli
        JOIN CONCERNER ON CONCERNER.numSort = SORTIE.numSort
        JOIN PRODUIT ON CONCERNER.numPdt = PRODUIT.numPdt
        WHERE PRODUIT.libPdt = "Fleur de sel"
        GROUP BY CLIENT.nomCli, CLIENT.precisionCli, CLIENT.villeCli;""",
        """SELECT CLIENT.nomCli, CLIENT.precisionCli, CLIENT.villeCli, SUM(qteSort*prixVente) As valeurTotAchaten€
        FROM CLIENT
        JOIN SORTIE ON CLIENT.numCli = SORTIE.numCli
        JOIN CONCERNER ON CONCERNER.numSort = SORTIE.numSort
        JOIN PRODUIT ON CONCERNER.numPdt = PRODUIT.numPdt
        JOIN COUTER ON COUTER.numPdt = PRODUIT.numPdt
        GROUP BY CLIENT.nomCli, CLIENT.precisionCli, CLIENT.villeCli
        HAVING SUM(qteSort*prixVente) >= 100000;""",
        """SELECT CLIENT.nomCli, CLIENT.precisionCli, CLIENT.villeCli
        FROM CLIENT
        WHERE CLIENT.numCli NOT IN (SELECT CLIENT.numCli
            FROM CLIENT
            JOIN SORTIE ON CLIENT.numCli = SORTIE.numCli);""",
        """INSERT INTO CLIENT
        VALUES(5, "GARNIER", "François", "NIORT");""",
        """CREATE USER 'Commercial' IDENTIFIED BY 'Commercial';
        GRANT SELECT ON SAUNIERS TO Commercial;
        GRANT SELECT ON CLIENTS TO Commercial;""",
        """SELECT PRODUIT.libPdt, SUM(CONCERNER.qteSort) AS totalVendu
        FROM PRODUIT
        JOIN CONCERNER ON PRODUIT.numPdt = CONCERNER.numPdt
        GROUP BY PRODUIT.libPdt
        ORDER BY totalVendu DESC;""",
        """SELECT PRODUIT.libPdt, SUM(CONCERNER.qteSort * COUTER.prixVente) AS revenuTotal
        FROM PRODUIT
        JOIN CONCERNER ON PRODUIT.numPdt = CONCERNER.numPdt
        JOIN COUTER ON PRODUIT.numPdt = COUTER.numPdt
        GROUP BY PRODUIT.libPdt
        ORDER BY revenuTotal DESC;""",
        """CREATE VIEW Sauniers (numSau, nom, prenom, ville, produit, qteProduite) AS
        SELECT SAUNIER.numSau, nomSau, prenomSau, villeSau, libPdt, SUM(qteEnt)
        FROM SAUNIER
        JOIN ENTREE ON SAUNIER.numSau = ENTREE.numSau
        JOIN PRODUIT ON ENTREE.numPdt = PRODUIT.numPdt
        GROUP BY SAUNIER.numSau, nomSau, prenomSau, villeSau, libPdt;""",
        """SELECT *
        FROM Sauniers
        WHERE produit = "Fleur de sel"
        ORDER BY qteProduite DESC;""",
        """SELECT *
        FROM Sauniers
        WHERE produit = "Gros sel"
        ORDER BY qteProduite DESC;"""
    ]

    queries_names = ["Quantité de fleur de sel achetée par client", "Quantité d'argent dépensée par client de plus de 100000€",
                     "Les clients qui n'ont rien acheté", "Ajout d'un client, François GARNIER", "Création d'un utilisateur, Commercial",
                     "Produits les plus vendus en termes de quantité totale", "Revenus totaux générés par produit", 
                     "Création d'une vue pour savoir ce que chaque saunier produit", "Les sauniers qui ont produit le plus de fleur de sel",
                     "Les sauniers qui ont produit le plus de gros sel"]

    # Fonction pour exécuter une requête
    def execute_predefined_query(query):
        try:
            cursor.execute(query)
            if query.lower().startswith("select"):
                rows = cursor.fetchall()
                columns = [desc[0] for desc in cursor.description]
                result_window = tk.Toplevel()
                result_window.title("Résultats de la Requête")
                taille_fenetre(result_window)

                result_tree = ttk.Treeview(result_window, columns=columns, show="headings")
                result_tree.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

                for col in columns:
                    result_tree.heading(col, text=col)
                    result_tree.column(col, width=100)

                for row in rows:
                    result_tree.insert("", "end", values=row)
                
                ttk.Button(result_window, text="Retour", command=result_window.destroy, width=30).pack(pady=10)
            else:
                db.commit()
                messagebox.showinfo("Succès", "Requête exécutée avec succès.")
        except mysql.connector.Error as err:
            messagebox.showerror("Erreur", f"Erreur lors de l'exécution de la requête : {err}")

    # Ajouter les boutons pour chaque requête
    for i, query in enumerate(queries):
        ttk.Button(query_buttons_window, text=queries_names[i], command=lambda q=query: execute_predefined_query(q), width=60).pack(pady=5)

    # Bouton pour fermer la fenêtre
    ttk.Button(query_buttons_window, text="Retour", command=query_buttons_window.destroy, width=30).pack(pady=10)


def open_db_connection_window():
    connection_window = tk.Tk()
    connection_window.title("Connexion à la Base de Données")

    taille_fenetre(connection_window)

    ttk.Label(connection_window, text="Connexion à la Base de Données", font=("Arial", 16)).pack(pady=20)

    # Champs pour saisir les informations de connexion
    frame = ttk.Frame(connection_window)
    frame.pack(pady=10)

    ttk.Label(frame, text="Hôte:").grid(row=0, column=0, padx=5, pady=5)
    host_entry = ttk.Entry(frame)
    host_entry.grid(row=0, column=1, padx=5, pady=5)
    host_entry.insert(0, "localhost")

    ttk.Label(frame, text="Utilisateur:").grid(row=1, column=0, padx=5, pady=5)
    user_entry = ttk.Entry(frame)
    user_entry.grid(row=1, column=1, padx=5, pady=5)
    user_entry.insert(0, "root")

    ttk.Label(frame, text="Mot de passe:").grid(row=2, column=0, padx=5, pady=5)
    password_entry = ttk.Entry(frame, show="*")
    password_entry.grid(row=2, column=1, padx=5, pady=5)

    ttk.Label(frame, text="Nom de la Base:").grid(row=3, column=0, padx=5, pady=5)
    db_name_entry = ttk.Entry(frame)
    db_name_entry.grid(row=3, column=1, padx=5, pady=5)
    db_name_entry.insert(0, "selmarin")  # Nom de la base de données par défaut

    # Fonction pour se connecter à une base de données existante
    def connect_to_db():
        host = host_entry.get()
        user = user_entry.get()
        password = password_entry.get()
        db_name = db_name_entry.get()

        if not db_name:
            messagebox.showerror("Erreur", "Veuillez renseigner le nom de la base de données.")
            return

        try:
            connection = mysql.connector.connect(host=host, user=user, password=password, database=db_name)
            global db, cursor
            db = connection
            cursor = db.cursor()
            handle_db_connection()  # Vérifier les tables et ouvrir la fenêtre appropriée
        except mysql.connector.Error as err:
            messagebox.showerror("Erreur", f"Erreur lors de la connexion à la base : {err}")

    # Fonction pour créer une nouvelle base de données
    def create_db():
        host = host_entry.get()
        user = user_entry.get()
        password = password_entry.get()
        db_name = db_name_entry.get()

        if not db_name:
            messagebox.showerror("Erreur", "Veuillez renseigner le nom de la base de données.")
            return

        try:
            connection = mysql.connector.connect(host=host, user=user, password=password)
            temp_cursor = connection.cursor()
            temp_cursor.execute("SHOW DATABASES")
            existing_databases = [db[0] for db in temp_cursor.fetchall()]

            if db_name in existing_databases:
                messagebox.showerror("Erreur", f"La base de données '{db_name}' existe déjà.")
                return

            temp_cursor.execute(f"CREATE DATABASE `{db_name}`")  # Utilisation de backticks pour éviter l'erreur 1064
            connection.database = db_name
            global db, cursor
            db = connection
            cursor = db.cursor()
            messagebox.showinfo("Succès", f"La base de données '{db_name}' a été créée et connectée.")
            open_sql_file_window()  # Ouvrir la fenêtre pour charger un fichier SQL
        except mysql.connector.Error as err:
            messagebox.showerror("Erreur", f"Erreur lors de la création de la base : {err}")

    # Boutons pour se connecter ou créer une base de données
    button_frame = ttk.Frame(connection_window)
    button_frame.pack(pady=20)

    ttk.Button(button_frame, text="Se Connecter", command=connect_to_db, width=30).pack(side=tk.LEFT, padx=10)
    ttk.Button(button_frame, text="Créer la Base", command=create_db, width=30).pack(side=tk.LEFT, padx=10)

    # Bouton pour supprimer les bases de données
    ttk.Button(connection_window, text="Supprimer les bases qui commencent par", 
               command=lambda: delete_databases_starting_with(db_name_entry.get()), 
               width=50).pack(pady=20)

    connection_window.mainloop()


def handle_db_connection():
    try:
        # Vérifier si les tables existent
        cursor.execute("SHOW TABLES")
        tables = cursor.fetchall()
        if tables:
            messagebox.showinfo("Info", "Connexion réussie. Les tables existent déjà.")
            open_menu_window()  # Aller au menu principal
        else:
            messagebox.showinfo("Info", "Connexion réussie. Les tables n'existent pas.")
            open_sql_file_window()  # Ouvrir la fenêtre pour charger un fichier SQL
    except mysql.connector.Error as err:
        messagebox.showerror("Erreur", f"Erreur lors de la vérification des tables : {err}")


def open_sql_file_window():
    close_all_windows()
    sql_window = tk.Tk()
    sql_window.title("Charger un fichier SQL")

    taille_fenetre(sql_window)

    ttk.Label(sql_window, text="Charger un fichier SQL pour créer les tables", font=("Arial", 14)).pack(pady=10)

    def load_sql_file():
        file_path = filedialog.askopenfilename(filetypes=[("SQL files", "*.sql")])
        if not file_path:
            return
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                sql_script = file.read()
                for statement in sql_script.split(";"):
                    if statement.strip():
                        cursor.execute(statement)
                db.commit()
                messagebox.showinfo("Succès", "Les tables ont été créées avec succès.")
                sql_window.destroy()
                open_data_sql_file_window()  # Aller à la fenêtre pour charger un fichier SQL de données
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de l'exécution du fichier SQL : {e}")

    ttk.Button(sql_window, text="Charger un fichier SQL", command=load_sql_file, width=30).pack(pady=10)
    ttk.Button(sql_window, text="Retour", command=sql_window.destroy, width=30).pack(pady=10)


def open_data_sql_file_window():
    data_sql_window = tk.Tk()
    data_sql_window.title("Charger un fichier SQL de données")

    taille_fenetre(data_sql_window)

    ttk.Label(data_sql_window, text="Charger un fichier SQL pour remplir les tables", font=("Arial", 14)).pack(pady=10)

    def load_data_sql_file():
        file_path = filedialog.askopenfilename(filetypes=[("SQL files", "*.sql")])
        if not file_path:
            return
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                sql_script = file.read()
                for statement in sql_script.split(";"):
                    if statement.strip():
                        cursor.execute(statement)
                db.commit()
                messagebox.showinfo("Succès", "Les données ont été insérées avec succès.")
                data_sql_window.destroy()
                open_menu_window()  # Aller au menu principal
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de l'exécution du fichier SQL : {e}")

    ttk.Button(data_sql_window, text="Charger un fichier SQL de données", command=load_data_sql_file, width=30).pack(pady=10)
    ttk.Button(data_sql_window, text="Retour", command=data_sql_window.destroy, width=30).pack(pady=10)


def open_requete_window():
    requete_window = tk.Toplevel()  # Utiliser Toplevel pour une nouvelle fenêtre
    requete_window.title("REQUETE")

    taille_fenetre(requete_window)

    # Bouton pour revenir au menu principal
    def return_to_menu():
        requete_window.destroy()

    ttk.Button(requete_window, text="Retour", command=return_to_menu, width=30).pack(pady=20)

# Fermer toutes les fenêtres Tkinter
def close_all_windows():
    if tk._default_root is not None:
        for window in list(tk._default_root.children.values()):
            window.destroy()
        if tk._default_root is not None:
            tk._default_root.destroy()


def delete_databases_starting_with(prefix):
    try:
        # Se connecter à la base de données sans spécifier de base particulière
        connection = mysql.connector.connect(host="localhost", user="root", password="")
        cursor = connection.cursor()

        cursor.execute("SHOW DATABASES")
        databases = cursor.fetchall()
        for db_name in databases:
            if db_name[0].startswith(prefix):
                cursor.execute(f"DROP DATABASE `{db_name[0]}`")
                print(f"Base de données supprimée : {db_name[0]}")
        messagebox.showinfo("Succès", f"Toutes les bases de données commençant par '{prefix}' ont été supprimées.")
    except mysql.connector.Error as err:
        messagebox.showerror("Erreur", f"Erreur lors de la suppression des bases de données : {err}")
    finally:
        cursor.close()
        connection.close()


open_db_connection_window()