-- Création

CREATE TABLE CLIENT(
   numCli VARCHAR(50),
   nomCli VARCHAR(50) NOT NULL,
   precisionCli VARCHAR(50) NOT NULL,
   villeCli VARCHAR(50) NOT NULL,
   PRIMARY KEY(numCli)
)ENGINE=InnoDB;

ALTER TABLE CLIENT  
ADD CONSTRAINT unique_nom_ville UNIQUE (nomCli, villeCli);

CREATE TABLE SAUNIER(
   numSau INT,
   nomSau VARCHAR(50) NOT NULL,
   prenomSau VARCHAR(50) NOT NULL,
   villeSau VARCHAR(50) NOT NULL,
   PRIMARY KEY(numSau)
)ENGINE=InnoDB;

CREATE TABLE PRODUIT(
   numPdt INT,
   libPdt VARCHAR(50) NOT NULL,
   stockPdt INT NOT NULL,
   PRIMARY KEY(numPdt)
)ENGINE=InnoDB;

CREATE TABLE SORTIE(
   numSort INT,
   -- dateSort DATETIME NOT NULL DEFAULT CONVERT(DATE, GETDATE()),
   dateSort DATETIME NOT NULL,
   numCli VARCHAR(50) NOT NULL,
   PRIMARY KEY(numSort),
   FOREIGN KEY(numCli) REFERENCES CLIENT(numCli)
)ENGINE=InnoDB;

CREATE TABLE ENTREE(
   numEnt INT,
   -- dateEnt DATETIME NOT NULL DEFAULT CONVERT(DATE, GETDATE()),
   dateEnt DATETIME NOT NULL,
   qteEnt INT NOT NULL CHECK (qteEnt > 0),
   numSau INT NOT NULL,
   numPdt INT NOT NULL,
   PRIMARY KEY(numEnt),
   FOREIGN KEY(numSau) REFERENCES Saunier(numSau),
   FOREIGN KEY(numPdt) REFERENCES PRODUIT(numPdt)
)ENGINE=InnoDB;

CREATE TABLE CONCERNER(
   numSort INT,
   numPdt INT,
   qteSort INT NOT NULL,
   PRIMARY KEY(numPdt, numSort),
   FOREIGN KEY(numPdt) REFERENCES PRODUIT(numPdt),
   FOREIGN KEY(numSort) REFERENCES SORTIE(numSort)
)ENGINE=InnoDB;

CREATE TABLE COUTER(
   numPdt INT,
   annee INT,
   prixAchat INT,
   prixVente INT,
   PRIMARY KEY(numPdt, annee),
   FOREIGN KEY(numPdt) REFERENCES PRODUIT(numPdt)
)ENGINE=InnoDB;


-- Insertion


INSERT INTO SAUNIER
VALUES(1, "YVAN", "Pierre", "Ars-En-Ré");
INSERT INTO SAUNIER
VALUES(2, "PETIT", "Marc", "Loix");

INSERT INTO PRODUIT
VALUES(1, "Gros sel", 2000);
INSERT INTO PRODUIT
VALUES(2, "Fleur de sel", 1000);

INSERT INTO CLIENT
VALUES(1,"CAVANA","Marie","LA ROCHELLE");
INSERT INTO CLIENT
VALUES(2,"BURLET","Michel","LAGORD");
INSERT INTO CLIENT
VALUES(3,"PEUTOT","Maurice","LAGORD");
INSERT INTO CLIENT
VALUES(4,"ORGEVAL","Centrale d’Achats","SURGERES");

INSERT INTO ENTREE
VALUES(20241, "2024-06-16 00:00:00", 1000, 1, 1);
INSERT INTO ENTREE
VALUES(20242, "2024-06-18 00:00:00", 500, 1, 2);
INSERT INTO ENTREE
VALUES(20243, "2024-07-10 00:00:00", 1500, 2, 2);

INSERT INTO SORTIE
VALUES(20241, "2024-07-16 00:00:00", 1);
INSERT INTO SORTIE
VALUES(20242, "2024-07-18 00:00:00", 1);
INSERT INTO SORTIE
VALUES(20243, "2024-08-10 00:00:00", 2);

INSERT INTO CONCERNER
VALUES(20241, 1, 300);
INSERT INTO CONCERNER
VALUES(20241, 2, 400);
INSERT INTO CONCERNER
VALUES(20242, 1, 200);
INSERT INTO CONCERNER
VALUES(20243, 1, 100);
INSERT INTO CONCERNER
VALUES(20243, 2, 500);

INSERT INTO COUTER
VALUES(1, 2023, 270, 280);
INSERT INTO COUTER
VALUES(2, 2023, 3900, 9500);
INSERT INTO COUTER
VALUES(1, 2024, 270, 290);
INSERT INTO COUTER
VALUES(2, 2024, 3800, 10000);
INSERT INTO COUTER
VALUES(1, 2025, 240, 300);
INSERT INTO COUTER
VALUES(2, 2025, 3500, 9000);


-- Execution des requêtes


-- Quantité de fleur de sel achetée par client
SELECT CLIENT.nomCli, CLIENT.precisionCli, CLIENT.villeCli, SUM(CONCERNER.qteSort) As qteAchatFleurDeSelenT
FROM CLIENT 
JOIN SORTIE ON CLIENT.numCli = SORTIE.numCli
JOIN CONCERNER ON CONCERNER.numSort = SORTIE.numSort
JOIN PRODUIT ON CONCERNER.numPdt = PRODUIT.numPdt
WHERE PRODUIT.libPdt = "Fleur de sel"
GROUP BY CLIENT.nomCli, CLIENT.precisionCli, CLIENT.villeCli;

-- Quantité d'argent dépensée par client de plus de 100000€
SELECT CLIENT.nomCli, CLIENT.precisionCli, CLIENT.villeCli, SUM(qteSort*prixVente) As valeurTotAchaten€
FROM CLIENT
JOIN SORTIE ON CLIENT.numCli = SORTIE.numCli
JOIN CONCERNER ON CONCERNER.numSort = SORTIE.numSort
JOIN PRODUIT ON CONCERNER.numPdt = PRODUIT.numPdt
JOIN COUTER ON COUTER.numPdt = PRODUIT.numPdt
GROUP BY CLIENT.nomCli, CLIENT.precisionCli, CLIENT.villeCli
HAVING SUM(qteSort*prixVente) >= 100000;

-- Les clients qui n'ont rien acheté
SELECT CLIENT.nomCli, CLIENT.precisionCli, CLIENT.villeCli
FROM CLIENT
WHERE CLIENT.numCli NOT IN (SELECT CLIENT.numCli
    FROM CLIENT
    JOIN SORTIE ON CLIENT.numCli = SORTIE.numCli);

-- Ajouter un client, ici François GARNIER
INSERT INTO CLIENT
VALUES(5, "GARNIER", "François", "NIORT");

-- Création d'un utilisateur Commercial qui a accès aux tables Sauniers et Clients pour trouver d'autres clients et sauniers
CREATE USER 'Commercial' IDENTIFIED BY 'Commercial';
GRANT SELECT ON SAUNIERS TO Commercial;
GRANT SELECT ON CLIENTS TO Commercial;

-- Produits les plus vendus en termes de quantité totale
SELECT PRODUIT.libPdt, SUM(CONCERNER.qteSort) AS totalVendu
FROM PRODUIT
JOIN CONCERNER ON PRODUIT.numPdt = CONCERNER.numPdt
GROUP BY PRODUIT.libPdt
ORDER BY totalVendu DESC;

-- Revenus totaux générés par produit
SELECT PRODUIT.libPdt, SUM(CONCERNER.qteSort * COUTER.prixVente) AS revenuTotal
FROM PRODUIT
JOIN CONCERNER ON PRODUIT.numPdt = CONCERNER.numPdt
JOIN COUTER ON PRODUIT.numPdt = COUTER.numPdt
GROUP BY PRODUIT.libPdt
ORDER BY revenuTotal DESC;

-- Création d'une vue pour savoir ce que chaque saunier produit
CREATE VIEW Sauniers (numSau, nom, prenom, ville, produit, qteProduite) AS
SELECT SAUNIER.numSau, nomSau, prenomSau, villeSau, libPdt, SUM(qteEnt)
FROM SAUNIER
JOIN ENTREE ON SAUNIER.numSau = ENTREE.numSau
JOIN PRODUIT ON ENTREE.numPdt = PRODUIT.numPdt
GROUP BY SAUNIER.numSau, nomSau, prenomSau, villeSau, libPdt;

-- Les sauniers qui ont produit le plus de fleur de sel
SELECT *
FROM Sauniers
WHERE produit = "Fleur de sel"
ORDER BY qteProduite DESC;

-- Les sauniers qui ont produit le plus de gros sel
SELECT *
FROM Sauniers
WHERE produit = "Gros sel"
ORDER BY qteProduite DESC;
