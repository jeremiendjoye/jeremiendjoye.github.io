Insert into client
Values(13, 'John', 'Doe', 'Niort');