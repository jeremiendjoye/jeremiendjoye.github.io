CREATE TABLE CLIENT(
   numCli VARCHAR(50),
   nomCli VARCHAR(50) NOT NULL,
   precisionCli VARCHAR(50) NOT NULL,
   villeCli VARCHAR(50) NOT NULL,
   PRIMARY KEY(numCli)
)ENGINE=InnoDB;

ALTER TABLE CLIENT  
ADD CONSTRAINT unique_nom_ville UNIQUE (nomCli, villeCli);

CREATE TABLE SAUNIER(
   numSau INT,
   nomSau VARCHAR(50) NOT NULL,
   prenomSau VARCHAR(50) NOT NULL,
   villeSau VARCHAR(50) NOT NULL,
   PRIMARY KEY(numSau)
)ENGINE=InnoDB;

CREATE TABLE PRODUIT(
   numPdt INT,
   libPdt VARCHAR(50) NOT NULL,
   stockPdt INT NOT NULL,
   PRIMARY KEY(numPdt)
)ENGINE=InnoDB;

CREATE TABLE SORTIE(
   numSort INT,
   -- dateSort DATETIME NOT NULL DEFAULT CONVERT(DATE, GETDATE()),
   dateSort DATETIME NOT NULL,
   numCli VARCHAR(50) NOT NULL,
   PRIMARY KEY(numSort),
   FOREIGN KEY(numCli) REFERENCES CLIENT(numCli)
)ENGINE=InnoDB;

CREATE TABLE ENTREE(
   numEnt INT,
   -- dateEnt DATETIME NOT NULL DEFAULT CONVERT(DATE, GETDATE()),
   dateEnt DATETIME NOT NULL,
   qteEnt INT NOT NULL CHECK (qteEnt > 0),
   numSau INT NOT NULL,
   numPdt INT NOT NULL,
   PRIMARY KEY(numEnt),
   FOREIGN KEY(numSau) REFERENCES Saunier(numSau),
   FOREIGN KEY(numPdt) REFERENCES PRODUIT(numPdt)
)ENGINE=InnoDB;

CREATE TABLE CONCERNER(
   numSort INT,
   numPdt INT,
   qteSort INT NOT NULL,
   PRIMARY KEY(numPdt, numSort),
   FOREIGN KEY(numPdt) REFERENCES PRODUIT(numPdt),
   FOREIGN KEY(numSort) REFERENCES SORTIE(numSort)
)ENGINE=InnoDB;

CREATE TABLE COUTER(
   numPdt INT,
   annee INT,
   prixAchat INT,
   prixVente INT,
   PRIMARY KEY(numPdt, annee),
   FOREIGN KEY(numPdt) REFERENCES PRODUIT(numPdt)
)ENGINE=InnoDB;
