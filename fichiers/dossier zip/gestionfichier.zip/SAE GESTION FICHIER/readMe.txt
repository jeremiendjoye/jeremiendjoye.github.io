**Guide d'utilisation du programme Python pour transformer votre fichier JSON en csv**

Ce fichier est un guide simple pour vous aider à utiliser le programme Python et transformer votre fichier JSON des évènements à Paris en un fichier CSV réutilisable. Suivez ces étapes pour effectuer la transformation facilement :

Etape 1 : Préparer le fichier
1. Glissez votre fichier dans le dossier contenant le programme Python.
2. Renommez le en "que-faire-a-paris-".

Etape 2 : Lancer le programme
1. Ouvrez le dossier dans votre environnement de développement habituel.
2. Lancez le programme Python lié. 
3. Sauf cas d'erreurs, un fichier CSV sera créé. Si une erreur survient, elle sera indiquée dans le terminal.

Etape 3 : Charger le fichier CSV dans Excel
1. Ouvrez Excel.
2. Allez dans l'onglet "Données".
3. Cliquez sur **A partir d'un fichier CSV/texte**.
4. Sélectionnez le fichier CSV que vous venez de créer, il sera automatiquement ajouté au dossier correspondant.
5. Dans les options de séparation, choisissez **Point-virgule** comme séparateur et **UTF-8** pour l'encodage.

---

Une fois ces étapes terminées, vous aurez accès à tous les événements à venir ou passés à Paris dans un fichier CSV, prêt à être analysé et utilisé.

---

NB : Pour certains évènements le code postal peut ne pas être affiché car rattaché à la ville ou contenant des espaces, Excel ne peut convertir l'ensemble en nombre. Il en va de même pour certains numéros de contact. 

AV.JN